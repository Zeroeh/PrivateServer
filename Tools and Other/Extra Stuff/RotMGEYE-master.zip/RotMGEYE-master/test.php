<?php
/**
 * test.php
 * Created at 5/19/14
 */

include 'engine/engine.php';
include 'layout/header.html';

render_image(3096);
