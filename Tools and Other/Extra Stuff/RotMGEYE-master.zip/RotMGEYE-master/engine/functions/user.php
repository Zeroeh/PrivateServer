<?php
/**
 * user.php
 * Created at 5/19/14
 */

class User {

    public function __construct($data = array()) {


    }
}
 