<?php
/**
 * characters.php
 * Created at 5/20/14
 */

return array('782' => array('Wizard', -798), '784' => array('Priest', -1806), '775' => array('Archer', -168), '798' => array('Warrior', -2184));