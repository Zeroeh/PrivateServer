RotMGWeb
========

RotMG Web engine for private servers

Main Developers
=========
- Alvaritos
- BlackRayquaza

Features
========

RotMG Web is a simple web application for RotMG private servers
We aim to create a free-open source Realmeye for private servers

- Built with PHP 5+
- Good and clean code (OOP)
